document.addEventListener('DOMContentLoaded', function() {
 if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
        initialViews = 'timeGridDay';
    }else{
        initialViews = 'timeGridWeek';
    }   
  
  var calendarEl = document.getElementById('calendar');
   var today = moment().day();
  
    var calendar = new FullCalendar.Calendar(calendarEl, {
    
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'timeGridWeek,timeGridDay,listWeek'
      },
   buttonText:    {
  today:    'Today',
 // month:    'month',
  week:     'Weekly',
  day:      'Daily',
  list:     'List'
},
  navLinks: true,
       firstDay: today,
       hiddenDays: [ 0 ],
       initialView: initialViews,
        editable: true,
        selectable: true, 
        unselectAuto:true,
        eventOverlap: false,
        eventColor: '#f16621', 
        slotDuration: '00:15',
        allDaySlot : false,
        eventStartEditable: false,
        eventDurationEditable:false,
        slotLabelInterval: "00:15",
        longPressDelay: 0,
        nowIndicator: "true", //indicator of current time
        slotMinTime: '09:00',
        slotMaxTime: '19:45',
        eventContent: function( arg ) {
      return { html: arg.event.title };
   },
 
 validRange: function(today) {
    return {
      start: today,
    };
  },
    events: 'https://fullcalendar.io/demo-events.json'
    });

    calendar.render();
});